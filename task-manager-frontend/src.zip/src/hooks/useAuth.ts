import { useAuth } from '../auth/AuthContext';

export default useAuth;
