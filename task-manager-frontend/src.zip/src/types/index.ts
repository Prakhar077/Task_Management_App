// src/types/index.ts
export interface Task {
  id: string;
  title: string;
  description: string;
  status?: 'pending' | 'in-progress' | 'completed';
  userId?: string;
}


export interface User {
  id: string;
  username: string;
  role: 'admin' | 'user';
}
